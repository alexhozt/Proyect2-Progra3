# domain/clientes.py

class Cliente:
    def __init__(self, id_cliente, nombre, nodo_id):
        """
        Representa un cliente del sistema logístico.

        :param id_cliente: ID único del cliente (ej. "C001")
        :param nombre: Nombre del cliente (ej. "Cliente 1")
        :param nodo_id: ID del nodo en el grafo asociado al cliente (ej. "A", "B", etc.)
        """
        self.id_cliente = id_cliente
        self.nombre = nombre
        self.nodo_id = nodo_id
        self.tipo = "cliente"
        self.total_pedidos = 0
        self.prioridad = "media"  # Puede ser 'alta', 'media', 'baja'

    def registrar_pedido(self):
        """
        Incrementa el contador de pedidos del cliente.
        """
        self.total_pedidos += 1

    def to_dict(self):
        """
        Convierte los datos del cliente a un diccionario útil para visualizar en Streamlit.
        """
        return {
            "id": self.id_cliente,
            "nombre": self.nombre,
            "nodo_id": self.nodo_id,
            "tipo": self.tipo,
            "total_pedidos": self.total_pedidos,
            "prioridad": self.prioridad
        }
